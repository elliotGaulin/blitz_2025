import random
from game_message import *

BIOMASSE_MAX_TO_SPAWNER = 8

class Bot:


    def __init__(self):
        self.state: TeamGameState = None

        print("Initializing your super mega duper bot")

    def get_next_move(self, game_message: TeamGameState) -> list[Action]:
        """
        Here is where the magic happens, for now the moves are not very good. I bet you can do better ;)
        """
        actions = []
        self.state = game_message

        print(self.state.lastTickErrors)


        actions += self.decision_spawner(game_message)

        ########################################################
        # to be removed
        my_team: TeamInfo = self.state.world.teamInfos[self.state.yourTeamId]
        if len(my_team.spores) == 0:
            actions.append(
                SpawnerProduceSporeAction(spawnerId=my_team.spawners[0].id, biomass=20)
            )

        else:
            actions.append(
                SporeMoveToAction(
                    sporeId=my_team.spores[0].id,
                    position=Position(
                        x=random.randint(0, game_message.world.map.width - 1),
                        y=random.randint(0, game_message.world.map.height - 1),
                    ),
                )
            )
        ###########################################################

        # You can clearly do better than the random actions above. Have fun!!
        return actions

    def sporeMovementActions(self) -> list[SporeMoveToAction]:
        possibleTargets: list[list[int]] = self.getTargets()
        wantedTargets: dict[str, Position] = self.target_assignement(possibleTargets)
        actions: list[SporeMoveToAction] = []

        for spore in wantedTargets:
            action = SporeMoveToAction(spore, wantedTargets[spore])
            actions.append(action)

        return actions

    def target_assignement(self, targetTiles: list[list[int]]) -> dict[str, Position]:
        spores = self.game_state.world.teamInfos[self.game_state.yourTeamId].spores
        assignments: dict[str, Position] = {}
        assigned_tiles: set[Position] = set()

        for spore in spores:
            best_tile = None

            distance = 1

            x = spore.position.x
            y = spore.position.y

            while best_tile is None:
                pos = Position(x + distance ,y) # TODO : random start position
                nb_to_check = distance * 4 # number of tiles to check at this distance
                for _ in range(nb_to_check):
                    if (0 <= pos.x < self.state.world.map.width) and (0 <= pos.y < self.state.world.map.height):
                        if (targetTiles[pos.x][pos.y] > 0
                        and (pos.x, pos.y) not in assigned_tiles 
                        and (best_tile is None or targetTiles[pos.x][pos.y] > targetTiles[best_tile.x][best_tile.y])):
                            best_tile = Position(x = pos.x, y = pos.y)
                            break
                    
                    # Move to next tile in square ring
                    if pos.x == x + distance and pos.y < y + distance:
                        pos.y += 1
                        pos.x -= 1
                    
                    elif pos.y == y + distance and pos.x > x - distance:
                        pos.x -= 1
                        pos.y -= 1    
                    

            if best_tile:
                assignments[spore.id] = best_tile
                assigned_tiles.add((best_tile.x, best_tile.y))

        return assignments

    def getTargets(self) -> list[list[int]]:
        grid = self.state.world.ownershipGrid
        width = self.state.world.map.width
        height = self.state.world.map.height
        us = self.state.yourTeamId
        targets: list[list[int]] = [[0] * width for _ in range(height)]
        for i in range(width):
            for j in range(height):
                if grid[i][j] == us:
                    target = self.lookAround(Position(x=i, y=j))
                    if target is not None:
                        targets[i][j] = 1
        return targets


    def lookAround(self, position: Position) -> Position | None:
        targets: list[(Position, int)] = []  # position and how much we want it
        grid = self.state.world.ownershipGrid
        biomassGrid = self.state.world.biomassGrid
        us = self.state.yourTeamId

        for i in range(position.x - 1, position.x + 1):
            for j in range(position.y - 1, position.y + 1):
                if grid[i][j] != us:
                    targets.append(
                        Position(x=i, y=j),
                        biomassGrid[i][j],
                    )

        if len(targets) != 0:
            best = min(targets, key=lambda x: x[1])
            return best[0]

        return None

    def create_spawner(self, game_state: TeamGameState):
        actions = []
        my_team: TeamInfo = game_state.world.teamInfos[game_state.yourTeamId]

        for spore in my_team.spores:
            if (my_team.nextSpawnerCost < BIOMASSE_MAX_TO_SPAWNER and spore.biomass >= my_team.nextSpawnerCost):
                actions.append(SporeCreateSpawnerAction(sporeId=spore.id))

        return actions
    
    def decision_spawner(self, game_state: TeamGameState):
        actions = []
        actions += self.create_spawner(game_state)

        return actions