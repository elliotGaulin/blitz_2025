import random
from game_message import *

BIOMASSE_MAX_TO_SPAWNER = 8
NUTRIENTS_MIN_TO_SPORE = 5
BIOMASS_FOR_SPORE = 4
SPORE_AMOUNT_FOR_PROTECTOR = 10
SPORE_AMOUNT_FOR_BIG_PROTECTOR = 20
SPORE_SMALL_PROTECTOR = 15 
SPORE_BIG_PROTECTOR = 30 
MAX_DISTANCE_FOR_TARGET = 40
BASE_TARGET_PRIORITY = 9999
PRIORITY_DONT_TOUCH = -1

class Bot:


    def __init__(self):
        self.state: TeamGameState = None

        print("Initializing your super mega duper bot")

    def get_next_move(self, game_message: TeamGameState) -> list[Action]:
        """
        Here is where the magic happens, for now the moves are not very good. I bet you can do better ;)
        """
        self.actions = []
        self.state = game_message

        print(self.state.lastTickErrors)


        self.actions += self.decision_spawner(game_message)
        self.actions += self.sporeMovementActions()
        self.actions += self.create_spore(game_message)

        ########################################################
        # to be removed
        # my_team: TeamInfo = self.state.world.teamInfos[self.state.yourTeamId]
        # if len(my_team.spores) == 0:
        #     self.actions.append(
        #         SpawnerProduceSporeAction(spawnerId=my_team.spawners[0].id, biomass=20)
        #     )

        # else:
        #     self.actions.append(
        #         SporeMoveToAction(
        #             sporeId=my_team.spores[0].id,
        #             position=Position(
        #                 x=random.randint(0, game_message.world.map.width - 1),
        #                 y=random.randint(0, game_message.world.map.height - 1),
        #             ),
        #         )
        #     )
        ###########################################################

        # You can clearly do better than the random actions above. Have fun!!
        return self.actions

    def sporeMovementActions(self) -> list[SporeMoveToAction]:
        possibleTargets: list[list[int]] = self.getTargets()

        print(f">>> Possible targets:\n{possibleTargets}")

        wantedTargets: dict[str, Position] = self.target_assignement(possibleTargets)
        
        print(f">>> Wanted targets:\n{wantedTargets}")
        
        actions: list[SporeMoveToAction] = []

        for spore in wantedTargets:
            action = SporeMoveToAction(spore, wantedTargets[spore])
            actions.append(action)

        print(f">>> MoveToActions:\n   ")

        return actions

    def target_assignement(self, targetTiles: list[list[int]]) -> dict[str, Position]:
        print("<<< Target tiles:")
        for row in targetTiles:
            print(row)
        print(">>> Target assignment")
        spores = self.state.world.teamInfos[self.state.yourTeamId].spores
        assignments: dict[str, Position] = {}
        assigned_tiles: set[Position] = set()

        for spore in spores:
            # check if spore already has an action
            spore_already_has_action = False
            # for action in self.actions:
            #     if action.sporeId == spore.id:
            #         spore_already_has_action = True
            #         print(" Spore ", spore.id, " already has an action, skipping")
            #         break
            if spore_already_has_action:
                continue
            print("Assigning target for spore ", spore.id)
            print("spore pos: ", spore.position)
            best_tile = None

            distance = 1
            spore_pos = spore.position
            
            while best_tile is None:
                # print(" Checking distance ", distance)
                rand_pos = random.randint(0,3)
                pos_x = spore_pos.x
                pos_y = spore_pos.y
                if rand_pos == 0:
                    pos_x += distance
                elif rand_pos == 1:
                    pos_x -= distance
                elif rand_pos == 2:
                    pos_y += distance
                else:
                    pos_y -= distance
                pos = Position(spore_pos.x + distance, spore_pos.y)  # starting position
                
                # pos = Position(spore_pos.x + distance ,spore_pos.y) # TODO : random start position
                nb_to_check = distance * 4 # number of tiles to check at this distance
                dir_x = 1
                dir_y = 1
                for _ in range(nb_to_check):
                    if (0 <= pos.x < self.state.world.map.width) and (0 <= pos.y < self.state.world.map.height):
                        # print("  Position ", pos, " has target value ", targetTiles[pos.x][pos.y])
                        if (targetTiles[pos.x][pos.y] > PRIORITY_DONT_TOUCH
                        and (pos.x, pos.y) not in assigned_tiles 
                        and (best_tile is None or targetTiles[pos.x][pos.y] > targetTiles[best_tile.x][best_tile.y])):
                            best_tile = Position(x = pos.x, y = pos.y)
                    
                    if pos.x == spore_pos.x + distance:
                        dir_x = -1
                    elif pos.x == spore_pos.x - distance:
                        dir_x = 1
                        
                    if pos.y == spore_pos.y + distance:
                        dir_y = -1
                    elif pos.y == spore_pos.y - distance:
                        dir_y = 1
                        
                    pos.x += dir_x
                    pos.y += dir_y
                    
                    # # Move to next tile in diamond (distance doesn't account for diagonals)
                    # if pos.x == spore_pos.x + distance and pos.y < spore_pos.y + distance:
                    #     pos.y += 1
                    #     pos.x -= 1
                    # elif pos.y == spore_pos.y + distance and pos.x > spore_pos.x - distance:
                    #     pos.y += 1
                    #     pos.x -= 1
                    # elif pos.x == spore_pos.x - distance and pos.y > spore_pos.y - distance:
                    #     pos.y -= 1
                    #     pos.x += 1
                    # elif pos.y == spore_pos.y - distance and pos.x < spore_pos.x + distance:
                    #     pos.y -= 1
                    #     pos.x += 1
                    # elif pos.x < spore_pos.x + distance and pos.y < spore_pos.y + distance:
                    #     pos.x += 1
                    #     pos.y += 1
                    # elif pos.x > spore_pos.x - distance and pos.y > spore_pos.y - distance:
                    #     pos.x -= 1
                    #     pos.y -= 1
                    # elif pos.x < spore_pos.x + distance and pos.y > spore_pos.y - distance:
                    #     pos.x += 1
                    #     pos.y -= 1
                    # elif pos.x > spore_pos.x - distance and pos.y < spore_pos.y + distance:
                    #     pos.x -= 1
                    #     pos.y += 1
                    # else:
                    #     print("Error in target assignment")
                    #     break # should not happen
                    
                distance += 1
                if distance > MAX_DISTANCE_FOR_TARGET:
                    print(" No target found within max distance")
                    break
            if best_tile:
                assignments[spore.id] = best_tile
                assigned_tiles.add((best_tile.x, best_tile.y))

        print("<<< Target assignment")
        return assignments

    def getTargets(self) -> list[list[int]]:
        grid = self.state.world.ownershipGrid
        width = self.state.world.map.width
        height = self.state.world.map.height
        us = self.state.yourTeamId
        targets: list[list[int]] = [[BASE_TARGET_PRIORITY] * width for _ in range(height)]

        print(f">>> getting targets on grid:\n{grid}")

        for i in range(width):
            for j in range(height):
                if grid[i][j] == us:
                    targets[i][j] = PRIORITY_DONT_TOUCH
                    target = self.lookAround(Position(x=i, y=j))
                    if target is not None:
                        targets[target[0].x][target[0].y] = target[1]

        
        return targets


    def lookAround(self, position: Position) -> tuple[Position, int] | None:
        targets: list[tuple[Position, int]] = []  # position and how much we want it
        grid = self.state.world.ownershipGrid
        biomassGrid = self.state.world.biomassGrid
        us = self.state.yourTeamId
        width = self.state.world.map.width
        height = self.state.world.map.height

        # basic looking for empty tiles
        for i in range(position.x - 1, position.x + 1):
            if (i > width) or (i < 0):  # if i out of bounds
                continue
            for j in range(position.y - 1, position.y + 1):
                if (j > height) or (j < 0):  # if j out of bounds
                    continue
                if (position.y - j != 0) and (
                    position.x - i != 0
                ):  # fuck les diagonales
                    continue

                if grid[i][j] != us:
                    print(f">>> LookAround Looking at {i}, {j}")
                    print(f">>> LookAround saw biomass:\n{biomassGrid[i][j]}")
                    targets.append(
                        (
                            Position(x=i, y=j),
                            BASE_TARGET_PRIORITY - biomassGrid[i][j],
                        )
                    )

        if len(targets) != 0:
            best = targets[0]
            for t in targets:
                if t[1] > best[1]:
                    best = t

            print(f">>> lookAround said: {best}")
            return best

        return None

    def check_spawner_positions(self, game_state: TeamGameState, spore):
        my_team: TeamInfo = game_state.world.teamInfos[game_state.yourTeamId]

        for spawner in my_team.spawners:
            if(spore.position == spawner.position):
                return True

        return False
    
    def create_spawner(self, game_state: TeamGameState):
        actions = []
        my_team: TeamInfo = game_state.world.teamInfos[game_state.yourTeamId]

        for spore in my_team.spores:
            if (my_team.nextSpawnerCost < BIOMASSE_MAX_TO_SPAWNER and
                 spore.biomass >= my_team.nextSpawnerCost and
                 not self.check_spawner_positions(game_state, spore)):
                actions.append(SporeCreateSpawnerAction(sporeId=spore.id))

        return actions
    
    def decision_spawner(self, game_state: TeamGameState):
        actions = []
        actions += self.create_spawner(game_state)

        return actions
    
    def create_spore(self, game_state: TeamGameState):
        actions = []
        my_team: TeamInfo = game_state.world.teamInfos[game_state.yourTeamId]

        for spawner in my_team.spawners:
            if(my_team.nutrients > NUTRIENTS_MIN_TO_SPORE):
                actions.append(SpawnerProduceSporeAction(spawner.id, self.spore_size_decision(game_state)))

        return actions
    
    def spore_size_decision(self, game_state: TeamGameState):
        actions = []
        my_team: TeamInfo = game_state.world.teamInfos[game_state.yourTeamId]
        spore_amount = len(my_team.spores)

        if(spore_amount > SPORE_AMOUNT_FOR_BIG_PROTECTOR):
            return SPORE_BIG_PROTECTOR
        elif(spore_amount > SPORE_AMOUNT_FOR_PROTECTOR):
            return SPORE_SMALL_PROTECTOR
        
        return  BIOMASS_FOR_SPORE